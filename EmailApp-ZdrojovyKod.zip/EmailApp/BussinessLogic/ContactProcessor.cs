﻿using Dapper;
using DataLibrary.Models;
using EmailApp;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SQLite;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataLibrary.BussinessLogic
{    //trida ContactProcessor poskytuje rozhraní mezi aplikací a databází sqlite
    public class ContactProcessor
    {
        //metoda pro načtení kontaktui do databáze
        public static List<PersonModel> LoadContacts()
        {
           //using (IDB.... ) určuje propojení mezi databází a aplikací
            using (IDbConnection cnn = new SQLiteConnection(LoadConnectionString()))
            {
                //pomocí dapper extenze se provede selet query proti tabulkce Contacts v databázi
                var output = cnn.Query<PersonModel>("select * from Contacts", new DynamicParameters());
                //vrátí obsah databáze jako list objektů PersonModel
                return output.ToList();
            }
            
        }

        public static void SaveContact(string firtstName, string lastName, string address, string emailAddress)
        {
            using (IDbConnection cnn = new SQLiteConnection(LoadConnectionString(), true))
            {
                //metoda SaveContact převezme údaje od uživatele a namapuje je na objekt třídy PersonModel
                PersonModel person = new PersonModel
                {
                    FirstName = firtstName,
                    LastName = lastName,
                    Address = address,
                    EmailAddress = emailAddress
                };
                //Mapovaný zápis do tabulky contacts, Execute je metoda dapperu. Na sql query se mapuje objekt person
                cnn.Execute("insert into Contacts (FirstName, LastName, Address, EmailAddress) values(@FirstName, @LastName, @Address, @EmailAddress)", person);
            }

        }

        private static string LoadConnectionString(string id = "Default")
        {
            return ConfigurationManager.ConnectionStrings[1].ConnectionString;
        }

    }
}
