﻿using DataLibrary.BussinessLogic;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace EmailApp
{
    public partial class MailerList : System.Web.UI.Page
    {
        //globální list pData
        private List<PersonaModel> pData;

        //funkce volaná při načtení stránky
        protected void Page_Load(object sender, EventArgs e)
        {            
            pData = LoadPData();
            BindData(pData);
        }

        private List<PersonaModel> LoadPData()
        {
            List<PersonaModel> personData = new List<PersonaModel>();

            //mapování obsahu tabulky na list objektů
            var data = ContactProcessor.LoadContacts();
            //iterace listu objektů pro plnění repeateru tablulky v UI
            foreach (var value in data)
            {
                {
                    //volání konstruktoru třídy PersonaModel
                    personData.Add(new PersonaModel
                    (
                        value.FirstName,
                        value.LastName,
                        value.Address,
                        value.EmailAddress
                    ));
                }
            }

            //vrací list pro plnění tabulky repeaterem
            

            return personData;
        }

        private void BindData(List<PersonaModel> data1)
        {

            //mapuje data z funkce Load na repeater v UI
            rptPeople.DataSource = data1;
            rptPeople.DataBind();
        }
    }
    //definování datového modelu pro užití v kódu za stránkou
    public class PersonaModel
    {
        public string FirstName
        {
            get;
            set;
        }
        public string LastName
        {
            get;
            set;
        }
        public string Address
        {
            get;
            set;
        }
        public string EmailAddress
        {
            get;
            set;
        }

        //kontsruktor třídy PersonaModel
        public PersonaModel(string firstName, string lastName, string address, string emailAddress)
        {
            FirstName = firstName;
            LastName = lastName;
            Address = address;
            EmailAddress = emailAddress;
        }
    }
}