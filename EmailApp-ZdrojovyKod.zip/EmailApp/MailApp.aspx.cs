﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DataLibrary.BussinessLogic;

namespace EmailApp
{
    public partial class MailApp : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnEvent_Click(object sender, EventArgs e)
        {

            //zavolá metodu SaveContact v datové vrstvě (BussinessLogic/ContactProcessor)
            ContactProcessor.SaveContact(txtFirstName.Text, txtLastName.Text, txtAddress.Text, txtEmailAdress.Text);
            //int RecordCreated = PeopleProcessor.CreateRecord(txtFirstName.Text, txtLastName.Text, txtAddress.Text, txtEmailAdress.Text);
            Response.Redirect("~/MailerList.aspx");
        }
    }
}