﻿

//funkce z jquery pro zaskrtnuti vsech checkboxu
function checkbox() {
        $('input[name=sendmail]').prop('checked', true); 
}
//funkce z jquery pro odoznaceni vsech checkboxu
function ucheckbox() {
        $('input[name=sendmail]').prop('checked', false);
}

function GetCheckedAdress() {

    var contacts = [];
    var contacts1 = [];

    //reference pro tabulku maillist
    var tbl = document.getElementById("MailList");
    //reference pro vsechny input fields typu checkbox
    var checker = tbl.getElementsByClassName("sndml");
    console.log(checker);
    //smyčka iterující podél tabulky s kontakty
    for (var i = 0; i < checker.length; i++) {
        //jquery kontrola jestli je v jednotlivem radku zaskrutnuty checkbox
        if ($(checker[i]).prop("checked") == true) {
            //pokud je zaskrtnuty, vezme se hodnota čtvrtého sloupce (index 3)
            var addr = $('#MailList').find("tr").eq(i + 1).find("td").eq(3).html();
            //volá se jquery funkce trim, která odstraní mezery v textz
            var trimmed = $.trim(addr);
            //přiřadí se hodnota z tabulky do array contacts 1
            contacts.push(trimmed);
        }
    }

    //for smyčka pro rozdělení kontaktů do skupin po 20 členech

    //kontrolní proměná
    var LoopControl = 0;
    //for smyčka iterující kontakty
    for (var i = 0; i < contacts.length; i++) {
        //if statement provádějící rozdělení kontaktů do skupiny po 20
        if (LoopControl < 20) {
            //vložení členu contacts v pozici i do array contacts1
            contacts1.push(contacts[i]);
            //přičte 1 ke kontrolní proměnné
            LoopControl = LoopControl + 1;
        }
        //pokud přesáhne kontrolní prom. 20, zavolá se funkce SendMail s prvními 20 kontakty
        //poté je array contacts vynulováno a je do něj vložen první člen z další skupiny po 20 kontaktech
        //Loop Control se vynuluje a smyčka pokračuje
        else {
            SendMail(contacts1);
            contacts1 = [];
            contacts1.push(contacts[i]);
            LoopControl = 0;
        }
    }

    SendMail(contacts1);

    console.log(contacts);
    //SendMail(contacts);
    //SendMail(contacts);
}

//Funkce pro zaslání emailu
//v outlooku by měla otevřít několik oken po 20 kontaktech, ve windows 10 mail klientu otevře nový email s posledními n kontakty, zbytek lzte najít ve složce drafts
function SendMail(contacts) {
    var email = contacts;
    var subject = 'Hromadny email';
    var emailBody = 'Telo zpravy';
    var attach = 'path';
    document.location = "mailto:" + email + "?subject=" + subject + "&body=" + emailBody +
        "?attach=" + attach;
}

//funkce pro 